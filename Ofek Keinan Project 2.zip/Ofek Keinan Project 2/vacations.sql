-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2023 at 01:05 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vacations`
--
CREATE DATABASE IF NOT EXISTS `vacations` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `vacations`;

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `country_id` int(11) NOT NULL,
  `country_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`country_id`, `country_name`) VALUES
(1, 'Greece'),
(2, 'Germany'),
(3, 'UK'),
(4, 'Italy'),
(5, 'Netherlands'),
(6, 'Hungary'),
(7, 'Turkey'),
(8, 'Bulgaria'),
(9, 'Spain'),
(10, 'France');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `user_id` int(11) NOT NULL,
  `vacation_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role_name`) VALUES
(1, 'Admin'),
(2, 'User');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `email`, `password`, `role_id`) VALUES
(1, 'Ofek', 'Keinan', 'ofek.keinan@gmail.com', '1234', 1),
(2, 'Asaf', 'Fink', 'asafink@gmail.com', '1234', 2);

-- --------------------------------------------------------

--
-- Table structure for table `vacations`
--

CREATE TABLE `vacations` (
  `vacation_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `vacation_description` varchar(300) NOT NULL,
  `check_in_date` date NOT NULL,
  `check_out_date` date NOT NULL,
  `vacation_price` int(11) NOT NULL,
  `photo_file_name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vacations`
--

INSERT INTO `vacations` (`vacation_id`, `country_id`, `vacation_description`, `check_in_date`, `check_out_date`, `vacation_price`, `photo_file_name`) VALUES
(1, 1, 'Vacation package to Athens for 2 adults,\r\n21/01/24 - 25/01/24.\r\nIncluding 4 nights at Academias Hotel Autograph Collection with breakfast, Regular Room.\r\nRound-trip flights from TLV to ATH.\r\nPrice: $1,923.', '2024-01-21', '2024-01-25', 1923, 'Athens.png'),
(2, 2, 'Vacation package to Berlin for 2 adults,\r\n22/02/24 - 25/02/24.\r\nIncluding 3 nights at Park Inn By Radisson Berlin - Alexanderplatz Hotel with breakfast, Standard Room.\r\nRound-trip flights from TLV to BER.\r\nPrice: $1,291.', '2024-02-22', '2024-02-25', 1291, 'Berlin.png'),
(3, 3, 'Vacation package to London for 2 adults and 2 childs,\r\n14/04/24 - 17/04/24.\r\nIncluding 3 nights at The Cumberland Ex Hard Rock Hotel with breakfast, Gold Family Room.\r\nRound-trip flights from TLV to LHR.\r\nPrice: $4919.', '2024-04-14', '2024-04-17', 4919, 'London.png'),
(4, 4, 'Vacation package to Rome for 2 adults,\r\n21/12/23 - 24/12/23.\r\nIncluding 3 nights at Unahotels Tratevere Hotel with breakfast, Classic Room.\r\nRound-trip flights from TLV to FCO.\r\nPrice: $1,348.', '2023-12-21', '2023-12-24', 1348, 'Rome.png'),
(5, 5, 'Vacation package to Amsterdam for 2 adults,\r\n21/12/23 - 24/12/23.\r\nIncluding 3 nights at Mövenpick Hotel with breakfast, Classic Room.\r\nRound-trip flights from TLV to AMS.\r\nPrice: $2,367.', '2023-12-21', '2023-12-24', 2367, 'Amsterdam.png'),
(6, 6, 'Vacation package to Budapest for 2 adults,\r\n01/02/24 - 04/02/24.\r\nIncluding 3 nights at Continental Hotel with breakfast, Standard Room.\r\nRound-trip flights from TLV to BUD.\r\nPrice: $1,147.', '2024-02-01', '2024-02-04', 1147, 'Budapest.png'),
(7, 7, 'Vacation package to Antalya for 2 adults,\r\n15/02/24 - 18/02/24.\r\nIncluding 3 nights at Well Palace Side Ex Crown Charm Hotel with all inclusive, Standard Room.\r\nRound-trip flights from TLV to AYT.\r\nPrice: $868.', '2024-02-15', '2024-02-18', 868, 'Antalya.png'),
(8, 8, 'Vacation package to Bucharest for 2 adults,\r\n11/01/24 - 14/01/24.\r\nIncluding 3 nights at Radisson Blu Hotel with breakfast, Standard Room.\r\nRound-trip flights from TLV to OTP.\r\nPrice: $1,361.', '2024-01-11', '2024-01-14', 1361, 'Bucharest.png'),
(9, 9, 'Vacation package to Barcelona for 2 adults and 2 childs,\r\n26/01/24 - 29/01/24.\r\nIncluding 3 nights at The Atiram Arenas Ex Husa Arenas Hotel with breakfast, Standard Room.\r\nRound-trip flights from TLV to BCN.\r\nPrice: €2,327', '2024-01-26', '2024-01-29', 2327, 'Barcelona.png'),
(10, 10, 'Vacation package to Paris for 2 adults and 1 child,\r\n25/04/24 - 29/04/24.\r\nIncluding 4 nights at Victor Hugo Hotel with breakfast, Standard Room.\r\nRound-trip flights from TLV to CDG.\r\nPrice: $3071.', '2024-04-25', '2024-04-29', 3071, 'Paris.png'),
(11, 9, 'Vacation package to Madrid for 2 adults,\r\n15/03/24 - 18/03/24.\r\nIncluding 3 nights at Aloft Madrid Gran Via Hotel with breakfast, Standard Room.\r\nRound-trip flights from TLV to MAD.\r\nPrice: €1,885.', '2024-03-15', '2024-03-18', 1885, 'Madrid,png'),
(12, 8, 'Vacation package to Sofia for 2 adults,\r\n11/01/24 - 14/01/24.\r\nIncluding 3 nights at Marinela Sofia Hotel with breakfast, Standard Room.\r\nRound-trip flights from TLV to SOF.\r\nPrice: $665.', '2024-01-11', '2024-01-14', 665, 'Sofia.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`user_id`,`vacation_id`),
  ADD KEY `vacation_id` (`vacation_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `vacations`
--
ALTER TABLE `vacations`
  ADD PRIMARY KEY (`vacation_id`),
  ADD KEY `country_id` (`country_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vacations`
--
ALTER TABLE `vacations`
  MODIFY `vacation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `likes_ibfk_1` FOREIGN KEY (`vacation_id`) REFERENCES `vacations` (`vacation_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `likes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`);

--
-- Constraints for table `vacations`
--
ALTER TABLE `vacations`
  ADD CONSTRAINT `vacations_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `countries` (`country_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
