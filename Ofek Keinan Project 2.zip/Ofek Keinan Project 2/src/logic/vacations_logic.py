from utils.dal import DAL
from models.vacation_model import *
from utils.image_handler import ImageHandler

class VacationsLogic:

    # ctor - Create a DAL object
    def __init__(self):
        self.dal = DAL()

    # Get all vacations:
    def get_all_vacations(self):
        sql = "SELECT vacations.*, countries.country_name as country FROM vacations JOIN countries ON vacations.country_id = countries.country_id ORDER BY check_in_date"
        return self.dal.get_table(sql)
        
    # Get single vacation:
    def get_one_vacation(self, vacation_id):
        sql = "SELECT vacations.*, countries.country_name as country FROM vacations JOIN countries ON vacations.country_id = countries.country_id WHERE vacation_id = %s"
        return self.dal.get_scalar(sql, (vacation_id, ))
    
    # Get all countries:
    def get_all_countries(self):
        sql = "SELECT * FROM countries"
        countries = self.dal.get_table(sql)
        return countries

    # Add new vacation:
    def add_vacation(self, vacation):
        image_name = ImageHandler.save_image(vacation.image)
        sql = "INSERT INTO vacations (country_id, vacation_description, check_in_date, check_out_date, vacation_price, photo_file_name) VALUES(%s, %s, %s, %s, %s, %s)"
        return self.dal.insert(sql, (vacation.country_id, vacation.vacation_description, vacation.check_in_date, vacation.check_out_date, vacation.vacation_price, image_name))

    # Update existing vacation:
    def update_vacation(self, vacation):
        old_image_name = self.__get_old_image_name(vacation.vacation_id)
        image_name = ImageHandler.update_image(old_image_name, vacation.image)
        sql = "UPDATE vacations SET country_id = %s, vacation_description = %s, check_in_date = %s, check_out_date = %s, vacation_price = %s, photo_file_name = %s WHERE vacation_id = %s"
        return self.dal.update(sql, (vacation.country_id, vacation.vacation_description, vacation.check_in_date, vacation.check_out_date, vacation.vacation_price, image_name, vacation.vacation_id))
        
    # Delete existing vacation:
    def delete_vacation(self, vacation_id):
        image_name = self.__get_old_image_name(vacation_id)
        ImageHandler.delete_image(image_name)
        sql = "DELETE FROM vacations WHERE vacation_id = %s"
        self.dal.delete(sql, (vacation_id, ))

    # Get old (existing) image name:
    def __get_old_image_name(self, id):
        sql = "SELECT photo_file_name FROM vacations WHERE vacation_id = %s"
        result = self.dal.get_scalar(sql, (id, ))
        return result["photo_file_name"]

    # Close resources:
    def close(self):
        self.dal.close()