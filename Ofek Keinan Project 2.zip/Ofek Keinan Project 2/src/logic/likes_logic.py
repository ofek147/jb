from utils.dal import *

class LikesLogic:

    # ctor - Create a DAL object:
    def __init__(self):
        self.dal = DAL()

    # Add a like:
    def add_like(self, user_id, vacation_id):
        sql = "INSERT INTO likes(user_id, vacation_id) VALUES(%s, %s)"
        result = self.dal.insert(sql, (user_id, vacation_id))
        return result

    # Delete a like:
    def delete_like(self, user_id, vacation_id):
        sql = "DELETE FROM likes WHERE likes.user_id = %s AND likes.vacation_id = %s"
        result = self.dal.delete(sql, (user_id, vacation_id))
        return result
    
    # Get all liked vacations:
    def get_all_liked_vacations(self):
        sql = "SELECT * FROM likes"
        return self.dal.get_table(sql)

    # Close resources:
    def close(self):
        self.dal.close()