from logic.vacations_logic import VacationsLogic
from flask import request # Request object arrived from the frontend
from models.vacation_model import VacationModel
from models.client_errors import ResourceNotFoundError, ValidationError

class VacationsFacade:
    
    # ctor - Creating a business logic object:
    def __init__(self):
        self.logic = VacationsLogic()

    # Get all vacation sorted by old to new:
    def get_all_vacations(self):
        vacations = self.logic.get_all_vacations()
        return vacations

    # Get one vacation:
    def get_one_vacation(self, vacation_id):
        vacation = self.logic.get_one_vacation(vacation_id)
        if not vacation: raise ResourceNotFoundError(vacation_id)
        return vacation

    # Get all countries:
    def get_all_countries(self):
        countries = self.logic.get_all_countries()
        return countries

    # Add new vacation:
    def add_vacation(self):
        country_id = request.form.get("country_id")
        vacation_description = request.form.get("vacation_description")
        check_in_date = request.form.get("check_in_date")
        check_out_date = request.form.get("check_out_date")
        vacation_price = request.form.get("vacation_price")
        image = request.files["image"]
        vacation = VacationModel(None, country_id, vacation_description, check_in_date, check_out_date, vacation_price, image)
        error = vacation.validate_insert()
        if error: raise ValidationError(error, vacation)
        self.logic.add_vacation(vacation)

    # Update existing vacation:
    def update_vacation(self):
        vacation_id = request.form.get("vacation_id")
        country_id = request.form.get("country_id")
        vacation_description = request.form.get("vacation_description")
        check_in_date = request.form.get("check_in_date")
        check_out_date = request.form.get("check_out_date")
        vacation_price = request.form.get("vacation_price")
        image = request.files["image"]
        vacation = VacationModel(vacation_id, country_id, vacation_description, check_in_date, check_out_date, vacation_price, image)
        error = vacation.validate_update()
        if error: raise ValidationError(error, vacation)
        self.logic.update_vacation(vacation)
        
    # Delete vacation:
    def delete_vacation(self, vacation_id):
        self.logic.delete_vacation(vacation_id)        
    
    # Close resources:
    def close(self):
        self.logic.close()