from logic.likes_logic import *
from logic.vacations_logic import *
from flask import request, session

class LikesFacade:
    
    # ctor - Creating a business logic object:
    def __init__(self):
        self.likes_logic = LikesLogic()
        self.vacations_logic = VacationsLogic()
                
    # Add or delete like for vacation:
    def like(self):
        user = session.get("current_user")
        user_id = user["user_id"]
        vacation_id = request.form.get("vacation_id")
        all_liked_vacations = self.likes_logic.get_all_liked_vacations()
        
        for liked_v in all_liked_vacations:
            if int(user_id) == liked_v["user_id"] and int(vacation_id) == liked_v["vacation_id"]:
                return self.likes_logic.delete_like(user_id, vacation_id)
        
        self.likes_logic.add_like(user_id, vacation_id)

    # Get all liked vacations:
    def get_all_liked_vacations(self):
        liked_vacations = self.likes_logic.get_all_liked_vacations()
        return liked_vacations

    # Get a dictionary for all the likes for each vacation:
    def likes_counter(self):
        all_vacations = self.vacations_logic.get_all_vacations()
        all_liked_vacations = self.likes_logic.get_all_liked_vacations()
        likes_counter = {}

        for vacation in all_vacations:
            vacation_id = vacation['vacation_id']
            likes_counter[vacation_id] = 0

        for vacation in all_liked_vacations:
            vacation_id = vacation['vacation_id']
            
            if vacation_id in likes_counter:
                likes_counter[vacation_id] += 1
        
        likes_counter = [{"vacation_id": key, "likes": value} for key, value in likes_counter.items()]      

        return likes_counter

    # Close resources:
    def close(self):
        self.likes_logic.close()