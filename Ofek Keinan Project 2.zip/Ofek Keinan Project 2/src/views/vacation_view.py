from flask import Blueprint, render_template, send_file, redirect, url_for, request, session
from facades.vacations_facade import VacationsFacade
from facades.auth_facade import AuthFacade
from facades.likes_facade import LikesFacade
from utils.image_handler import ImageHandler
from models.role_model import RoleModel
from models.client_errors import ResourceNotFoundError, ValidationError, AuthError

#  Managing the entire view:
vacations_blueprint = Blueprint("vacations_view", __name__)

# Create Facade:
vacation_facade = VacationsFacade()
auth_facade = AuthFacade()
likes_facade = LikesFacade()

# Display all products:
@vacations_blueprint.route("/vacations", methods=["GET", "POST"])
def list():
    try:
        auth_facade.block_anonymous()
        user = session.get("current_user")
        user_id = user["user_id"]
        if request.method == "GET":
            if user["role_id"]!= RoleModel.Admin.value: 
                likes_counter = likes_facade.likes_counter()
                liked_vacations =likes_facade.get_all_liked_vacations()
                vacations = vacation_facade.get_all_vacations()
                return render_template("vacations.html", vacations=vacations, likes_counter=likes_counter, liked_vacations=liked_vacations, user_id=int(user_id))
            else:
                vacations = vacation_facade.get_all_vacations()
                return render_template("admin.html", vacations=vacations)
        likes_facade.like()
        return redirect(url_for("vacations_view.list"))
    except AuthError as err:
        return redirect(url_for("auth_view.login", error=err.message))

# Return image file:
@vacations_blueprint.route("/vacations/images/<string:image_name>")
def get_image(image_name):
    image_path = ImageHandler.get_image_path(image_name)
    return send_file(image_path)

# Adding new vacation:
@vacations_blueprint.route("/vacations/new", methods=["GET", "POST"])
def insert():
    try:
        auth_facade.block_non_admin()
        if request.method == "GET":
            countries = vacation_facade.get_all_countries()
            return render_template("insert.html", countries=countries)
        vacation_facade.add_vacation()
        return redirect(url_for("vacations_view.list"))
    except AuthError as err:
        return redirect(url_for("vacations_view.list", error = err.message))
    except ValidationError as err:
        return render_template("insert.html", error = err.message)    

# Updating existing vacation:
@vacations_blueprint.route("/vacations/edit/<int:vacation_id>",  methods=["GET", "POST"])
def edit(vacation_id):
    try:
        auth_facade.block_non_admin()
        if request.method == "GET": 
            countries = vacation_facade.get_all_countries()
            one_vacation = vacation_facade.get_one_vacation(vacation_id)
            return render_template("edit.html", vacation=one_vacation, countries=countries)
        vacation_facade.update_vacation()
        return redirect(url_for("vacations_view.list"))
    except AuthError as err:
        return redirect(url_for("vacations_view.list", error = err.message))
    except ResourceNotFoundError as err:
        return render_template("404.html", error=err.message)
    except ValidationError as err:
        return render_template("edit.html", error = err.message, vacation=err.model) 

@vacations_blueprint.route("/vacations/delete/<int:vacation_id>")
def delete(vacation_id):
    try:
        auth_facade.block_non_admin()
        vacation_facade.delete_vacation(vacation_id)
        return redirect(url_for("vacations_view.list"))
    except AuthError as err:
        return redirect(url_for("vacations_view.list", error = err.message))