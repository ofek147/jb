from flask import Blueprint, render_template

#  Managing the entire view:
home_blueprint = Blueprint("home_view", __name__)

# Home display:
@home_blueprint.route("/")
@home_blueprint.route("/home")
def home():
    return render_template("home.html")
