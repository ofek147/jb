// Confirm before delete vacation:
function confirmDelete() {
    const ok = confirm("Are you sure?");
    if (!ok) event.preventDefault();
}

// Popping error message:
const errorSpan = document.querySelector(".error");
if (errorSpan) {
    setTimeout(() => {
        errorSpan.parentNode.removeChild(errorSpan);
    }, 4000);
}

// Date validation in edit vacation form:
function edit(){
    var checkInDate = document.getElementById("check_in_date").value;
    document.getElementById("check_out_date").setAttribute("min", checkInDate);
}

// Date validation in insert vacation form:
function insert(){
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
    var yyyy = today.getFullYear();

    today = yyyy + '-' + mm + '-' + dd;
    document.getElementById("check_in_date").setAttribute("min", today);
    document.getElementById("check_out_date").setAttribute("min", today); // Initially set minimum checkout date to today

    document.getElementById("check_in_date").addEventListener("change", function DateValidation() {
        var checkInDate = document.getElementById("check_in_date").value;
        document.getElementById("check_out_date").setAttribute("min", checkInDate);
        document.getElementById("check_out_date").value = checkInDate; // Set checkout date equal to checkin date
    });
}