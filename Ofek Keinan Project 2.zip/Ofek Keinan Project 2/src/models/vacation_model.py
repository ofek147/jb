from datetime import *

# Vacation model:
class VacationModel:
    
    # Vacation parameters:
    def __init__(self, vacation_id, country_id, vacation_description, check_in_date, check_out_date, vacation_price, image):
        self.vacation_id = vacation_id
        self.country_id =country_id
        self.vacation_description = vacation_description
        self.check_in_date = check_in_date
        self.check_out_date = check_out_date
        self.vacation_price = vacation_price
        self.image = image

    # Validating a new vacation insert:
    def validate_insert(self):
        now = datetime.now()
        now = datetime(int(now.year), int(now.month), int(now.day))
        print(now)
        if not self.country_id: return "Missing country."
        if not self.vacation_description: return "Missing description."
        if not self.check_in_date: return "Missing check-in date."
        if not self.check_out_date: return "Missing check-out date."
        if not self.vacation_price: return "Missing price."
        if not self.image: return "Missing image."
        if len(self.vacation_description) < 10 or len(self.vacation_description) > 500: return "Description length must be 10 - 500 chars."
        if self.transform_date(self.check_in_date) < now: return "Check-in date can't be from the past."
        if self.transform_date(self.check_out_date) < now: return "Check-out date can't be from the past."
        if self.transform_date(self.check_out_date) < self.transform_date(self.check_in_date): return "Check-out date can't be earlier than check-in date."
        if float(self.vacation_price) < 0 or float(self.vacation_price) > 10000: return "Price must be 0 - 10000."
        return None

    # Validating an existing vacation update:
    def validate_update(self):
        if not self.vacation_id: return "Missing id."
        if not self.country_id: return "Missing country."
        if not self.vacation_description: return "Missing description."
        if not self.check_in_date: return "Missing check-in date."
        if not self.check_out_date: return "Missing check-out date."
        if not self.vacation_price: return "Missing price."
        if len(self.vacation_description) < 10 or len(self.vacation_description) > 500: return "Description length must be 10 - 500 chars."
        if self.transform_date(self.check_out_date) < self.transform_date(self.check_in_date): return "Check-out date can't be earlier than check-in date."
        if float(self.vacation_price) < 0 or float(self.vacation_price) > 10000: return "Price must be 0 - 10000 chars."
        return None
    
    # Transform str("YEAR-MONTH-DAY") into a datetime:
    @staticmethod
    def transform_date(date):

        # Get year from str:
        year = ""
        for ch in date:
            year += ch
            if len(year) == 4:
                break

        # Get month from str:
        month = ""
        temp = ""
        for ch in date:
            temp += ch
            if len(temp) > 5:
                month += ch
                if len(month) == 2:
                    break
        
        # Get day from str:
        day = ""
        temp = ""
        for ch in date:
            temp += ch
            if len(temp) > 8:
                day += ch

        # Return date:
        valid_date = datetime(int(year), int(month), int(day))
        return valid_date

