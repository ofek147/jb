import re

class CredentialsModel:

    def __init__(self, email, password):
        self.email = email
        self.password = password

    # Validating credentials:
    def validate(self):
        if not self.email: return "Missing email."
        if not self.password: return "Missing password."
        if len(self.email) < 5 or len(self.email) > 100: return "Email length must be 5 - 100 chars."
        if len(self.password) < 4 or len(self.password) >100: return "Password length must be 4 - 100 chars."
        if not CredentialsModel.validate_email(self.email): return "Email not valid"
        return None

    # Email validation:
    @staticmethod
    def validate_email(email):
        pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
        return re.match(pattern, email) is not None