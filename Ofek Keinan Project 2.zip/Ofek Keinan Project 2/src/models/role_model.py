from enum import Enum

class RoleModel(Enum):
    Admin = 1 # Same as the database id
    User = 2